CREATE DATABASE RaceDayDB;


USE RaceDayDB;



-- USER TABLE
CREATE TABLE [User]
(
    UserID INT IDENTITY(1,1) PRIMARY KEY,
    FullName VARCHAR(100) NOT NULL,
    Email VARCHAR(100) NOT NULL UNIQUE,
    PasswordHash VARCHAR(255) NOT NULL,
    PhoneNumber VARCHAR(20) NOT NULL,
    Role VARCHAR(20) NOT NULL
        CHECK (Role IN ('Organizer', 'Participant'))
);



-- ORGANIZER TABLE
CREATE TABLE Organizer
(
    OrganizerID INT IDENTITY(1,1) PRIMARY KEY,
    OrganizationName VARCHAR(100) NOT NULL,
    ContactNumber VARCHAR(20) NOT NULL,
    UserID INT NOT NULL UNIQUE,

    FOREIGN KEY (UserID)
        REFERENCES [User](UserID)
);



-- CATERY TABLE
CREATE TABLE Catery
(
    CateryID INT IDENTITY(1,1) PRIMARY KEY,
    CateryName VARCHAR(100) NOT NULL,
    Description VARCHAR(255)
);



-- EVENT TABLE
CREATE TABLE Event
(
    EventID INT IDENTITY(1,1) PRIMARY KEY,
    EventName VARCHAR(150) NOT NULL,
    EventDate DATE NOT NULL,
    Location VARCHAR(150) NOT NULL,
    Description VARCHAR(500),

    OrganizerID INT NOT NULL,
    CateryID INT NOT NULL,

    FOREIGN KEY (OrganizerID)
        REFERENCES Organizer(OrganizerID),

    FOREIGN KEY (CateryID)
        REFERENCES Catery(CateryID)
);



-- ENROLLMENT TABLE
CREATE TABLE Enrollment
(
    EnrollmentID INT IDENTITY(1,1) PRIMARY KEY,
    EnrollmentDate DATE NOT NULL DEFAULT GETDATE(),

    UserID INT NOT NULL,
    EventID INT NOT NULL,

    FOREIGN KEY (UserID)
        REFERENCES [User](UserID),

    FOREIGN KEY (EventID)
        REFERENCES Event(EventID),

    UNIQUE (UserID, EventID)
);



-- RESULT TABLE
CREATE TABLE Result
(
    ResultID INT IDENTITY(1,1) PRIMARY KEY,
    ResultTime TIME NOT NULL,
    Position INT NOT NULL,
    Remarks VARCHAR(255),

    EnrollmentID INT NOT NULL UNIQUE,
    UserID INT NOT NULL,
    OrganizerID INT NOT NULL,

    FOREIGN KEY (EnrollmentID)
        REFERENCES Enrollment(EnrollmentID),

    FOREIGN KEY (UserID)
        REFERENCES [User](UserID),

    FOREIGN KEY (OrganizerID)
        REFERENCES Organizer(OrganizerID),

    CHECK (Position > 0)
);